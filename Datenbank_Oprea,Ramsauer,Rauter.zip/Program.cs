﻿using MySql.Data.MySqlClient;

namespace ConsoleApp1_DB_try
{
    class Program
    {
        static void Main(string[] args)
        {
            string connectionString = "Server=localhost;Database=fahrrad;User=root;Password=;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            connection.Open();

            Console.WriteLine("Enter a number to see the tables:");
            Console.WriteLine("1. Fahrräder");
            Console.WriteLine("2. Kunden");
            Console.WriteLine("3. Hersteller");
            Console.WriteLine("4. Vermietung");
            Console.WriteLine("5. Wohnort");
            Console.WriteLine("6. Land");

            int table = Convert.ToInt32(Console.ReadLine());

            switch (table)
            {
                case 1:
                    DisplayTable(connection, "SELECT Bezeichnung, Rahmennummer, MietpreisProTag, Wert, Kaufdatum, Name FROM fahrrad INNER JOIN hersteller ON (hersteller.idHersteller = fahrrad.Hersteller_idHersteller)",
                        "Bezeichnung", "Rahmennummer", "MietpreisProTag", "Wert", "Kaufdatum", "Name");
                    break;
                case 2:
                    DisplayTable(connection, "SELECT Vorname, Name, Anschrift, PLZ, Ortsname FROM kunde INNER JOIN wohnort ON (wohnort.idWohnort = kunde.wohnort_idWohnort)",
                        "Vorname", "Name", "Anschrift", "PLZ", "Ortsname");
                    break;
                case 3:
                    DisplayTable(connection, "SELECT Name, EMail FROM hersteller",
                        "Name", "EMail");
                    break;
                case 4:
                    DisplayTable(connection, "SELECT Mietdatum, Mietbeginn, Mietende, Bezeichnung, Vorname, Name FROM mietvorgang " +
                        "INNER JOIN fahrrad ON (fahrrad.idFahrrad = mietvorgang.fahrrad_idFahrrad) INNER JOIN kunde ON (kunde.idKunde = mietvorgang.kunde_idKunde)",
                        "Mietdatum", "Mietbeginn", "Mietende", "Bezeichnung", "Vorname", "Name");
                    break;
                case 5:
                    DisplayTable(connection, "SELECT PLZ, Ortsname, Bezeichnung FROM wohnort INNER JOIN land ON (land.idLAnd = wohnort.Land_idLand)",
                        "PLZ", "Ortsname", "Bezeichnung");
                    break;
                case 6:
                    DisplayTable(connection, "SELECT Countrycode, Bezeichnung FROM land",
                        "Countrycode", "Bezeichnung");
                    break;
                default:
                    Console.WriteLine("Invalid selection.");
                    break;
            }

            connection.Close();
        }

        static void DisplayTable(MySqlConnection connection, string query, params string[] columns)
        {
            try
            {
                MySqlCommand command = new MySqlCommand(query, connection);
                MySqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    foreach (var column in columns)
                    {
                        Console.Write($"{column}: {reader[column]} \t");
                    }
                    Console.WriteLine();
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }
    }
}
